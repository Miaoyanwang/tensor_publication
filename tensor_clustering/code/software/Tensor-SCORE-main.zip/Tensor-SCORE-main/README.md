# Tensor-SCORE
 
Code repository for paper

    @misc{ke2020community,
      title={Community Detection for Hypergraph Networks via Regularized Tensor Power Iteration}, 
      author={Zheng Tracy Ke and Feng Shi and Dong Xia},
      year={2020},
      eprint={1909.06503},
      archivePrefix={arXiv},
      primaryClass={stat.ME}
    }
