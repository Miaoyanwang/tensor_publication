###### Supplementary Materials for ``Generalized tensor decomposition with features on multiple modes" ######

Supplementary Materials contain following files:

1. supplementary_notes.pdf: includes technical proofs, additional simulation, and data analysis results.

2. data_code.zip: includes our simulation codes, R-package "tensorregress", and datasets used in the paper. Specific introductions for the codes and simulation pipeline can be found in readme.txt contained in the .zip file. The R-package and datasets can also be accessed at https://cran.r-project.org/web/packages/tensorregress/index.html. 

